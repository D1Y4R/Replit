/**
 * Bu modül kaldırılmıştır.
 * İçgörüler özelliği artık kullanılmıyor.
 */