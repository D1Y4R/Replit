import requests
import json
import os
import logging
from flask import Blueprint, jsonify, request
from datetime import datetime, timedelta

# Logging
logger = logging.getLogger(__name__)

# API Keys
FOOTBALL_DATA_API_KEY = os.environ.get('FOOTBALL_DATA_API_KEY', '668dd03e0aea41b58fce760cdf4eddc8')
API_FOOTBALL_KEY = os.environ.get('API_FOOTBALL_KEY', '2f0c06f149e51424f4c9be24eb70cb8f')

# Blueprint definition
api_v3_bp = Blueprint('api_v3', __name__, url_prefix='/api/v3')

# API Football endpoints
@api_v3_bp.route('/fixtures', methods=['GET'])
def get_fixtures():
    try:
        date = request.args.get('date', datetime.now().strftime("%Y-%m-%d"))
        league = request.args.get('league', '')  # Default to all leagues
        logger.info(f"Fetching fixtures for date: {date}, league: {league if league else 'all leagues'}")

def convert_apifootball_to_standard(matches_data):
    """API-Football verilerini standart formata dönüştür"""
    converted_data = {
        "response": []
    }
    
    for match in matches_data:
        fixture = {
            "fixture": {
                "id": match.get('match_id'),
                "date": match.get('match_date') + 'T' + match.get('match_time') + 'Z',
                "status": {
                    "short": "NS" if match.get('match_status') == '' else match.get('match_status')[:2],
                    "long": match.get('match_status') or 'SCHEDULED'
                },
                "venue": {
                    "name": match.get('match_stadium', '')
                }
            },
            "league": {
                "name": match.get('league_name', ''),
                "logo": match.get('league_logo', '')
            },
            "teams": {
                "home": {
                    "name": match.get('match_hometeam_name', ''),
                    "logo": match.get('team_home_badge', '')
                },
                "away": {
                    "name": match.get('match_awayteam_name', ''),
                    "logo": match.get('team_away_badge', '')
                }
            },
            "goals": {
                "home": match.get('match_hometeam_score', ''),
                "away": match.get('match_awayteam_score', '')
            }
        }
        converted_data["response"].append(fixture)
    
    return converted_data


        timezone = request.args.get('timezone', 'Europe/Istanbul')

        url = "https://v3.football.api-sports.io/fixtures"
        params = {
            "date": date,
            "timezone": timezone
        }

        if league:
            params["league"] = league

        headers = {
            'x-rapidapi-key': API_FOOTBALL_KEY,
            'x-rapidapi-host': 'v3.football.api-sports.io'
        }

        response = requests.get(url, headers=headers, params=params)
        result = response.json()

        if 'errors' in result and result['errors']:
            logger.error(f"API-Football errors: {result['errors']}")
            # If API limit is reached, use football-data.org as fallback
            logger.info("Switching to football-data.org API due to API-Football errors")
            return get_football_data_fixtures(date)

        # Check if the response is valid but empty
        if 'response' in result and len(result['response']) == 0:
            logger.warning(f"API-Football returned empty response for date {date}")
            logger.info("Trying football-data.org API for possible data")
            fallback_result = get_football_data_fixtures(date)
            # If fallback also has no matches, return original empty result
            fallback_data = fallback_result.json if hasattr(fallback_result, 'json') else {}
            if 'response' in fallback_data and len(fallback_data['response']) > 0:
                return fallback_result

        return jsonify(result)
    except Exception as e:
        logger.error(f"Error getting fixtures: {str(e)}")
        return jsonify({"errors": True, "message": str(e)}), 500

# Football-data.org fallback
def get_football_data_fixtures(date):
    try:
        # Önce API-Football ile deneyelim
        url = "https://apiv3.apifootball.com/"
        params = {
            'action': 'get_events',
            'from': date,
            'to': date,
            'APIkey': API_FOOTBALL_KEY
        }
        
        response = requests.get(url, params=params)
        if response.status_code == 200 and isinstance(response.json(), list) and len(response.json()) > 0:
            # API-Football verisi başarıyla alındı, converter'a gönder
            return convert_apifootball_to_standard(response.json())
        
        # API-Football çalışmazsa football-data.org ile devam et
        url = "https://api.football-data.org/v4/matches"
        headers = {'X-Auth-Token': FOOTBALL_DATA_API_KEY}
        params = {"date": date}

        response = requests.get(url, headers=headers, params=params)
        data = response.json()

        # Convert football-data.org format to api-football format
        converted_data = {
            "response": []
        }

        if 'matches' in data:
            for match in data['matches']:
                fixture = {
                    "fixture": {
                        "id": match.get('id'),
                        "date": match.get('utcDate'),
                        "status": {
                            "short": "NS" if match.get('status') == 'SCHEDULED' else match.get('status')[:2],
                            "long": match.get('status')
                        },
                        "venue": {
                            "name": match.get('venue')
                        }
                    },
                    "league": {
                        "name": match.get('competition', {}).get('name'),
                        "logo": match.get('competition', {}).get('emblem')
                    },
                    "teams": {
                        "home": {
                            "name": match.get('homeTeam', {}).get('shortName'),
                            "logo": match.get('homeTeam', {}).get('crest')
                        },
                        "away": {
                            "name": match.get('awayTeam', {}).get('shortName'),
                            "logo": match.get('awayTeam', {}).get('crest')
                        }
                    },
                    "goals": {
                        "home": match.get('score', {}).get('fullTime', {}).get('home'),
                        "away": match.get('score', {}).get('fullTime', {}).get('away')
                    }
                }
                converted_data["response"].append(fixture)

        return jsonify(converted_data)
    except Exception as e:
        logger.error(f"Error getting football-data fixtures: {str(e)}")
        return jsonify({"errors": True, "message": str(e)}), 500

@api_v3_bp.route('/fixtures/team/<int:team_id>', methods=['GET'])
def get_team_matches(team_id):
    try:
        last_count = int(request.args.get('last', 5))  # Son kaç maçı alacağız

        url = "https://v3.football.api-sports.io/fixtures"
        params = {
            "team": team_id,
            "last": last_count
        }

        headers = {
            'x-rapidapi-key': API_FOOTBALL_KEY,
            'x-rapidapi-host': 'v3.football.api-sports.io'
        }

        response = requests.get(url, headers=headers, params=params)
        result = response.json()

        if 'errors' in result and result['errors']:
            logger.error(f"API-Football errors: {result['errors']}")
            # If API limit is reached, use football-data.org as fallback
            return get_football_data_team_matches(team_id)

        # Sadece son n maçı al
        if 'response' in result and len(result['response']) > 0:
            result['response'] = sorted(
                result['response'], 
                key=lambda x: x['fixture']['date'], 
                reverse=True
            )[:last_count]

        return jsonify(result)

    except Exception as e:
        logger.error(f"Error getting team matches: {str(e)}")
        return jsonify({"errors": True, "message": str(e)}), 500

def get_football_data_team_matches(team_id):
    try:
        # Football Data API'de son N maçı almak için bir endpoint yok
        # Bu yüzden tüm maçları çekip filtrelememiz gerekiyor
        url = f"https://api.football-data.org/v4/teams/{team_id}/matches"
        headers = {'X-Auth-Token': FOOTBALL_DATA_API_KEY}
        params = {"status": "FINISHED"}

        response = requests.get(url, headers=headers, params=params)
        data = response.json()

        # Convert football-data.org format to api-football format
        converted_data = {
            "response": []
        }

        if 'matches' in data:
            # En son 5 maçı al
            recent_matches = sorted(data['matches'], key=lambda x: x.get('utcDate'), reverse=True)[:5]

            for match in recent_matches:
                fixture = {
                    "fixture": {
                        "id": match.get('id'),
                        "date": match.get('utcDate'),
                        "status": {
                            "short": match.get('status')[:2],
                            "long": match.get('status')
                        },
                        "venue": {
                            "name": match.get('venue')
                        }
                    },
                    "league": {
                        "name": match.get('competition', {}).get('name'),
                        "logo": match.get('competition', {}).get('emblem')
                    },
                    "teams": {
                        "home": {
                            "name": match.get('homeTeam', {}).get('shortName'),
                            "logo": match.get('homeTeam', {}).get('crest')
                        },
                        "away": {
                            "name": match.get('awayTeam', {}).get('shortName'),
                            "logo": match.get('awayTeam', {}).get('crest')
                        }
                    },
                    "goals": {
                        "home": match.get('score', {}).get('fullTime', {}).get('home'),
                        "away": match.get('score', {}).get('fullTime', {}).get('away')
                    }
                }
                converted_data["response"].append(fixture)

        return jsonify(converted_data)
    except Exception as e:
        logger.error(f"Error getting football-data team matches: {str(e)}")
        return jsonify({"errors": True, "message": str(e)}), 500

@api_v3_bp.route('/status')
def api_status():
    return jsonify({"status": "ok", "message": "API is working"})

@api_v3_bp.route('/api/train-neural-network', methods=['POST'])
def train_neural_network():
    """Sinir ağı modelini eğit (artık otomatik yapılıyor)"""
    try:
        from main import predictor
        success = predictor.collect_training_data()
        if success:
            return jsonify({"success": True, "message": "Sinir ağı modelleri başarıyla eğitildi."})
        else:
            return jsonify({"success": False, "message": "Yeterli veri bulunamadı veya eğitim başarısız oldu. Sinir ağları tahmin sırasında otomatik olarak eğitilecektir."})
    except Exception as e:
        logger.error(f"Sinir ağı eğitimi sırasında hata: {str(e)}")
        return jsonify({"error": str(e)}), 500

@api_v3_bp.route('/api/predict-match/<home_team_id>/<away_team_id>')
def api_v3_predict_match(home_team_id, away_team_id):
    from main import predictor
    home_name = request.args.get('home_name', '')
    away_name = request.args.get('away_name', '')
    force_update = request.args.get('force_update', 'false').lower() == 'true'

    try:
        prediction = predictor.predict_match(home_team_id, away_team_id, home_name, away_name, force_update)
        if prediction:
            # Simplify prediction data by removing complex card and corner predictions
            # to ensure lighter response payload
            if 'predictions' in prediction and 'betting_predictions' in prediction['predictions']:
                betting_predictions = prediction['predictions']['betting_predictions']
                # Remove corner and card predictions to reduce complexity
                if 'cards_over_3_5' in betting_predictions:
                    del betting_predictions['cards_over_3_5']
                if 'corners_over_9_5' in betting_predictions:
                    del betting_predictions['corners_over_9_5']
            return jsonify(prediction)
        else:
            return jsonify({"error": "Tahmin yapılamadı. Yeterli veri bulunmuyor."}), 400
    except Exception as e:
        logger.error(f"API v3 tahmin yapılırken hata: {str(e)}")
        return jsonify({"error": str(e)}), 500

@api_v3_bp.route('/api/advanced-predictions/<home_team_id>/<away_team_id>')
def advanced_predictions(home_team_id, away_team_id):
    """Gelişmiş tahminleri döndüren API endpoint"""
    home_name = request.args.get('home_name', '')
    away_name = request.args.get('away_name', '')
    force_update = request.args.get('force_update', 'false').lower() == 'true'
    prediction_type = request.args.get('type', 'all')  # all, exact_score, ht_ft, cards_corners, goals
    predictor = MatchPredictor()

    try:
        full_prediction = predictor.predict_match(home_team_id, away_team_id, home_name, away_name, force_update)
        
        if not full_prediction:
            return jsonify({"error": "Tahmin yapılamadı. Yeterli veri bulunmuyor."}), 400
            
        # Sadece istenen tahmin türünü döndür
        if prediction_type == 'exact_score':
            return jsonify({
                "match": f"{home_name} vs {away_name}",
                "exact_score": full_prediction['predictions']['betting_predictions']['exact_score']
            })
        elif prediction_type == 'ht_ft':
            return jsonify({
                "match": f"{home_name} vs {away_name}",
                "half_time_full_time": full_prediction['predictions']['betting_predictions']['half_time_full_time']
            })
        elif prediction_type == 'cards_corners':
            return jsonify({
                "match": f"{home_name} vs {away_name}",
                "cards_over_3_5": full_prediction['predictions']['betting_predictions']['cards_over_3_5'],
                "corners_over_9_5": full_prediction['predictions']['betting_predictions']['corners_over_9_5']
            })
        elif prediction_type == 'goals':
            return jsonify({
                "match": f"{home_name} vs {away_name}",
                "first_goal": full_prediction['predictions']['betting_predictions']['first_goal'],
                "over_2_5_goals": full_prediction['predictions']['betting_predictions']['over_2_5_goals'],
                "over_3_5_goals": full_prediction['predictions']['betting_predictions']['over_3_5_goals'],
                "both_teams_to_score": full_prediction['predictions']['betting_predictions']['both_teams_to_score']
            })
        else:
            # Tüm tahminleri döndür
            return jsonify({
                "match": f"{home_name} vs {away_name}",
                "advanced_predictions": full_prediction['predictions']['betting_predictions'],
                "expected_goals": full_prediction['predictions']['expected_goals']
            })
            
    except Exception as e:
        return jsonify({"error": str(e)}), 500